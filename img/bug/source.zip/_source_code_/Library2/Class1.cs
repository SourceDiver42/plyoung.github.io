﻿using UnityEngine;
using System;
using Library1;

namespace Library2
{
	[Serializable]
    public class Class1: BaseClass
    {
		public string fooB;
    }
}
