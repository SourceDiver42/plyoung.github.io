﻿using UnityEngine;
using System;

namespace Library1
{
	[Serializable]
    public class BaseClass: ScriptableObject
    {
		public string fooA;
    }
}
