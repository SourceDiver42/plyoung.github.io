﻿using UnityEngine;
using UnityEditor;
using System;
using Library2;

namespace Library2Editor
{
    public class TestEditor
    {
		[MenuItem("Bug Test/Recreate Test Asset")]
		public static void CreateTestAsset()
		{
			// remove old asset if present
			string fn = "Assets/test.asset";
			AssetDatabase.DeleteAsset(fn);

			// create new asset
			ScriptableObject asset = ScriptableObject.CreateInstance(typeof(Class1));
			AssetDatabase.CreateAsset(asset, fn);
			AssetDatabase.SaveAssets();
		}
    }
}
